export const PRIMARY_COLOR = "#ff7900";
export const SECONDARY_COLOR = "#fde9da";


// HTTPS
export const HTTPS_UNAUTHORIZED = 401
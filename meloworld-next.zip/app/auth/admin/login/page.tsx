import React from "react";
import LoginForm from "src/components/forms/login";

const AdminLogin = () => {
  return <LoginForm userRole="admin" />;
};

export default AdminLogin;

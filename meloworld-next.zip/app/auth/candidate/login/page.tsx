import React from "react";
import LoginForm from "src/components/forms/login";

const CandidateLogin = () => {
  return <LoginForm userRole="candidate" />;
};

export default CandidateLogin;

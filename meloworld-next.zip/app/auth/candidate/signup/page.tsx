import React from "react";
import SignUpForm from "@/components/forms/signup";
import CandidateSignUpForm from "@/components/forms/candidate-signup";

const Candidateignup = () => {
  return (
      <CandidateSignUpForm />
  );
};

export default Candidateignup;

import React from "react";
import LoginForm from "src/components/forms/login";

const OrgLogin = () => {
  return <LoginForm userRole="org" />;
};

export default OrgLogin; 
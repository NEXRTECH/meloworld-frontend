import React from 'react'

const CandidatesPanel = () => {
  return (
    <div className='dashboard-panel'>CandidatesPanel</div>
  )
}

export default CandidatesPanel
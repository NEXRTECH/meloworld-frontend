import React from 'react'

const SettingsPanel = () => {
  return (
    <div className='dashboard-panel'>SettingsPanel</div>
  )
}

export default SettingsPanel
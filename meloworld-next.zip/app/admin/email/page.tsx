import React from 'react'

const EmailPanel = () => {
  return (
    <div className='dashboard-panel'>EmailPanel</div>
  )
}

export default EmailPanel